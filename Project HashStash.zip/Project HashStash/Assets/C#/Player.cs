﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {


    public int score = 0;
    // Use this for initialization
    void Awake()
    {
        //ResetScore();
        score = 0;
        Debug.Log(score);
    }
    /*
    // Update is called once per frame
    void Update()
    {
        Debug.Log("score __" + score);
    }
    
    public void ResetScore()
    {
        if (score != 0)
        {
            score = 0;
        }
        //Debug.Log("score " + score);
    }

    public void incScore()
    {
        score++;
        //Debug.Log(score);
    }
    private void scoreplus()
    {
        score = score + 1;
        Debug.Log("score is "+score);
    }*/
    //3.8 up down
    //-6.7
    //3
   
}
