﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemy : MonoBehaviour {

    //public GameObject control;
    //private GameObject joystick;
    public bool GameOver = false;
    private float enemysize = 0.7f;
    //public GameObject player;

    //public GameObject GameOverText;
    

    // Use this for initialization
	void Start ()
    {
        float x, y,size = enemysize/2f ;
        bool check = false;
        int count = 0;
        while (check == false)//repete till open space found
        {
            x = Random.Range(-6.7f, 3f);
            y = Random.Range(-3.8f, 3.8f);
            if (!Physics2D.OverlapArea(new Vector2(x - size, y + size), new Vector2(x + size, y - size)))
            {
                check = true;
                transform.position = new Vector3(x, y);                
            }
            count++;
            if (count > 20)
                check = true;              
        }
    }
	
    
	// Update is called once per frame
	void Update ()
    {
	    
	}

    private void OnTriggerEnter2D(Collider2D other)    
    {
        //Debug.Log(other.gameObject.name + " collided with " + this.name);
        if (other.tag == "Player")
        {
            //Debug.Log(other.gameObject.name + " collided with " + this.name);
            GameObject.FindWithTag("joystick").GetComponent<joystick>().enabled = false;
            GameObject.FindWithTag("GameOver").GetComponent<SpriteRenderer>().enabled = true;
            //player.GetComponent<Player>().ResetScore();
            Debug.Log("Game Over");
            //GameOverText.SetActive(true);

            //other.GetComponent<Player>().score = 0;
            // = true;
        }
    }
}
