﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class joystick : MonoBehaviour {

    public Transform player;
    public Transform joystick_transform;
    public float speed = 5f;
    private bool touchStart = false;
    private Vector2 pointA;
    [SerializeField]
    private Vector2 pointB;
    private Vector2 offset;
    private Vector2 direction;
    private float joystick_rot;
    private float player_x, player_y;
    

	// Use this for initialization
	void Start ()
    {
        //player.GetComponent<Player>().ResetScore();
        pointA = new Vector2(transform.position.x , transform.position.y) ;
	}
	
	// Update is called once per frame
	void Update ()
    {
        if(Input.GetMouseButtonDown(0))//tap again to start moving
        {
            touchStart = true;
        }
		if(Input.GetMouseButton(0))
        {
            //touchStart = true ;
            pointB = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, Camera.main.transform.position.z));
        }
        else
        {
            touchStart = false;
        }
	}

    private void FixedUpdate()
    {
        if (touchStart == true)
        {
            offset = pointB - pointA;
            direction = Vector2.ClampMagnitude(offset, 1f);
            moveCharacter(direction);
            joystick_rot = Mathf.Atan2(offset.x, offset.y) * Mathf.Rad2Deg * -1f;

            //player.transform.eulerAngles = new Vector3(0,0,joystick_rot*-1f);
            //player.transform.GetChild(0).transform.eulerAngles = new Vector3(0, 0, joystick_rot);
            joystick_transform.transform.eulerAngles = new Vector3(0,0,joystick_rot);
        }
        else
        {
            joystick_transform.transform.eulerAngles = new Vector3(0,0,0);
        }
    }

    void moveCharacter(Vector2 direction)
    {
        
        player.Translate( direction * speed * Time.deltaTime);
        player_x = player.transform.position.x;
        player_y = player.transform.position.y;
        StayInside();
    }
    void StayInside()
    {
        bool turn = false;
        if (player_x >= 3f)
        {
            turn = true;
            player_x = 3f;
        }
        if (player_x <= -6.7f)
        {
            turn = true;
            player_x = -6.7f;
        }
        if (player_y >= 3.8f)
        {
            turn = true;
            player_y = 3.8f;
        }
        if (player_y <= -3.8f)
        {
            turn = true;
            player_y = -3.8f;
        }        

        player.transform.position = new Vector3(player_x, player_y);

        if (turn == true)
        {
            player.transform.GetChild(0).transform.Rotate( new Vector3(0, 0, 180));
            touchStart = false;
        }
        else
        {
            player.transform.GetChild(0).transform.eulerAngles = new Vector3(0, 0, joystick_rot);
        }
    }
}
