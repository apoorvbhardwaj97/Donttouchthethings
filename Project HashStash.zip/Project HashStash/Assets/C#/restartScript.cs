﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;


public class restartScript : MonoBehaviour {

    //public GameObject player;

    public void RestartGame()
    {
        //GameObject.FindWithTag("Player").GetComponent<Player>().score = 0;
        //GameObject.FindWithTag("Player").GetComponent<Player>().ResetScore();
        //player.GetComponent<Player>().ResetScore();
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
