﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour {

    public Text ScoreText;
    private int TheScore;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update ()
    {
        TheScore = GameObject.Find("Player").GetComponent<Player>().score;
        ScoreText.text = "Score:" + TheScore.ToString();
	}
}
