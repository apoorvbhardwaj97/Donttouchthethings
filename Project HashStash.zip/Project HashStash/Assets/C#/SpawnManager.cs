﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour {

    private bool gamestart = true;
    public int Nofenemy = 5;
    public int Nofreward = 5;
    public GameObject enemy;
    public GameObject reward;
	// Use this for initialization
	void Start ()
    {
	    if(gamestart == true)
        {
            for (int i = 0; i < Nofenemy;i++)
            {
                Instantiate(enemy);
            }               
            for (int i = 0; i< Nofreward;i++)
            {
                Instantiate(reward);
            }
        }
	}
	
	// Update is called once per frame
	void Update ()
    {
		
	}
}
